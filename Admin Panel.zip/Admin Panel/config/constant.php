<?php

return [
    'apikey' => [
        'server_key' => 'AAAAOkAYomw:APA91bEl45i9bZ9kBnOphf9tqAm9eNfxCJy6JNBCmbAdBnh1_txvJJHVE__hxeNy5ea3Wl4QyqS_cpTk5uHPuW_-pmOOachF1I1FL_IFiMGeKRWD4KxBQBQsD-yFj9welLWNt4UIDylD'
      ],
];
